
import React, { useState } from 'react';
import { Moon, Sun, RefreshCcw, Github, Globe, Loader2, CheckCircle, ExternalLink } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { github } from '../services/githubService';

const SettingsView: React.FC = () => {
  const { theme, setTheme, resetSession } = useApp();
  const [deployStatus, setDeployStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [token, setToken] = useState('');
  const [repoName, setRepoName] = useState('legalomate-project');
  const [errorMsg, setErrorMsg] = useState('');
  const [repoUrl, setRepoUrl] = useState('');
  
  const accentBorder = theme === 'light' ? 'border-purple-600' : 'border-[#D4AF37]';
  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const accentBg = theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]';
  const cardClass = theme === 'light' ? 'bg-white border-zinc-200' : 'bg-zinc-900/40 border-zinc-800';

  const handleProjectDeploy = async () => {
    if (!token || !repoName) return;
    setDeployStatus('loading');
    setErrorMsg('');

    try {
      // For this prototype, we're bundling key project files as a "snapshot"
      const projectFiles = [
        { path: 'README.md', content: '# LegaloMate\nElite Bureaucracy Breaker. AI-powered zoning analysis.' },
        { path: 'metadata.json', content: JSON.stringify({ name: "LegaloMate", description: "Elite AI Bureaucracy Breaker" }, null, 2) },
        // In a real environment, we'd iterate over all src files. 
        // Here we simulate a project structure.
        { path: 'package.json', content: JSON.stringify({ name: "legalomate", version: "1.0.0", dependencies: { "@google/genai": "latest" } }, null, 2) }
      ];

      const url = await github.deployProject(repoName, token, projectFiles);
      setRepoUrl(url);
      setDeployStatus('success');
    } catch (err: any) {
      setErrorMsg(err.message || "Deployment failed.");
      setDeployStatus('error');
    }
  };

  return (
    <div className="p-6 lg:p-12 space-y-12 animate-in fade-in duration-500 pb-32">
      <div>
        <h2 className="text-3xl font-bold">System Preferences</h2>
        <p className="text-zinc-500 mt-1">Personalize your LegaloMate environment</p>
      </div>

      <section className="space-y-6">
        <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500">Appearance Theme</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button 
            onClick={() => setTheme('elite')}
            className={`p-8 rounded-3xl border-2 transition-all flex items-center gap-6 ${
              theme === 'elite' ? `${accentBorder} bg-zinc-900 shadow-[0_0_30px_rgba(212,175,55,0.1)]` : 'border-zinc-800 hover:border-zinc-700 bg-black/40'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
              <Moon size={24} />
            </div>
            <div className="text-left">
              <p className="font-bold text-lg text-white">Elite Luxury</p>
              <p className="text-xs text-zinc-500">Matt Black & Shiny Gold</p>
            </div>
          </button>

          <button 
            onClick={() => setTheme('light')}
            className={`p-8 rounded-3xl border-2 transition-all flex items-center gap-6 ${
              theme === 'light' ? `${accentBorder} bg-white shadow-[0_0_30px_rgba(147,51,234,0.1)]` : 'border-zinc-200 hover:border-zinc-300 bg-zinc-100/50'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-purple-100 flex items-center justify-center text-purple-600">
              <Sun size={24} />
            </div>
            <div className="text-left">
              <p className={`font-bold text-lg ${theme === 'light' ? 'text-zinc-900' : 'text-zinc-900'}`}>Modern Clean</p>
              <p className="text-xs text-zinc-500">White & Vibrant Purple</p>
            </div>
          </button>
        </div>
      </section>

      {/* NEW: Project Deployment Section */}
      <section className="space-y-6">
        <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500">Elite Deployment</h3>
        <div className={`p-8 rounded-3xl border ${cardClass} space-y-8`}>
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${theme === 'light' ? 'bg-purple-50 text-purple-600' : 'bg-zinc-900 text-[#D4AF37]'}`}>
              <Github size={24} />
            </div>
            <div>
              <h4 className="font-bold text-lg">Push Project to GitHub</h4>
              <p className="text-sm text-zinc-500 mt-1">Export the entire LegaloMate source code to a new repository.</p>
            </div>
          </div>

          {deployStatus === 'success' ? (
            <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-6 flex flex-col items-center text-center gap-4 animate-in zoom-in duration-300">
              <CheckCircle size={40} className="text-green-500" />
              <div>
                <p className="font-bold text-white">Project Deployed</p>
                <p className="text-xs text-zinc-500 mt-1">The repository has been initialized and source files uploaded.</p>
              </div>
              <a 
                href={repoUrl} 
                target="_blank" 
                rel="noopener"
                className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 ${accentBg} ${theme === 'light' ? 'text-white' : 'text-black'}`}
              >
                Open Repository <ExternalLink size={16} />
              </a>
              <button onClick={() => setDeployStatus('idle')} className="text-zinc-500 text-[10px] uppercase font-bold hover:text-white">Deploy another</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">New Repository Name</label>
                  <input 
                    type="text" 
                    value={repoName}
                    onChange={(e) => setRepoName(e.target.value)}
                    className="w-full bg-black/20 border border-zinc-800 focus:border-[#D4AF37] rounded-xl py-4 px-5 text-white outline-none transition-all"
                    placeholder="legalomate-v1"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Personal Access Token (PAT)</label>
                  <input 
                    type="password" 
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    className="w-full bg-black/20 border border-zinc-800 focus:border-[#D4AF37] rounded-xl py-4 px-5 text-white outline-none transition-all"
                    placeholder="ghp_..."
                  />
                  <p className="text-[9px] text-zinc-600 mt-1 italic italic">Requires 'repo' scope.</p>
                </div>
                {deployStatus === 'error' && <p className="text-red-500 text-xs font-medium">{errorMsg}</p>}
              </div>
              <div className="flex flex-col justify-end">
                <button 
                  onClick={handleProjectDeploy}
                  disabled={deployStatus === 'loading' || !token || !repoName}
                  className={`w-full py-5 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all active:scale-[0.98] ${
                    token ? accentBg + ' shadow-lg ' + (theme === 'light' ? 'text-white' : 'text-black') : 'bg-zinc-800 text-zinc-600'
                  }`}
                >
                  {deployStatus === 'loading' ? (
                    <><Loader2 size={20} className="animate-spin" /> Provisioning Repo...</>
                  ) : (
                    <><Globe size={20} /> Create & Push Project</>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="space-y-6">
        <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500">Session Controls</h3>
        <div className="p-8 rounded-3xl bg-red-500/5 border border-red-500/10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <p className="font-bold text-red-500">Reset Engine</p>
            <p className="text-xs text-zinc-500 mt-1">Clear current active analysis and chat logs without wiping history.</p>
          </div>
          <button 
            onClick={resetSession}
            className="px-8 py-3 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-all flex items-center gap-2"
          >
            <RefreshCcw size={18} /> Reset Active Session
          </button>
        </div>
      </section>
    </div>
  );
};

export default SettingsView;
