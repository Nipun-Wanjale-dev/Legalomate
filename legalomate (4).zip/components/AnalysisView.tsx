
import React, { useState } from 'react';
import { Info, ExternalLink, Globe, Shield, Github, Share2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import GitHubSyncModal from './GitHubSyncModal';

const AnalysisView: React.FC = () => {
  const { analysis, theme } = useApp();
  const [showSync, setShowSync] = useState(false);
  
  if (!analysis) return null;

  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const cardClass = theme === 'light' ? 'bg-white border-zinc-200 shadow-sm' : 'bg-zinc-900/40 border-zinc-800';
  const summaryClass = theme === 'light' ? 'bg-purple-50 text-zinc-700' : 'bg-black/20 border-zinc-800/50 text-zinc-300';

  return (
    <div className="p-6 lg:p-10 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
      {/* Sync Modal */}
      {showSync && <GitHubSyncModal onClose={() => setShowSync(false)} />}

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 text-[#D4AF37]">
            <Globe size={14} className={accentText} />
            <span className={`text-[10px] font-bold uppercase tracking-widest ${accentText}`}>{analysis.detectedJurisdiction}</span>
          </div>
          <h2 className={`text-2xl lg:text-3xl font-bold tracking-tight ${theme === 'light' ? 'text-zinc-900' : 'text-white'}`}>{analysis.address}</h2>
          <div className="flex items-center gap-2 text-zinc-400">
            <Shield size={14} className={accentText} />
            <span className="text-sm">Zone: <b className={accentText}>{analysis.zoningDistrict}</b></span>
          </div>
        </div>

        <div className="flex gap-3">
          <button 
            onClick={() => setShowSync(true)}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all active:scale-95 shadow-lg ${
              theme === 'light' 
                ? 'bg-zinc-900 text-white hover:bg-black' 
                : 'bg-[#D4AF37] text-black hover:shadow-[0_0_20px_rgba(212,175,55,0.4)]'
            }`}
          >
            <Github size={16} /> Sync to GitHub
          </button>
          <button className={`p-3 rounded-xl border ${theme === 'light' ? 'border-zinc-200 text-zinc-400' : 'border-zinc-800 text-zinc-600 hover:text-white hover:border-zinc-400'} transition-all`}>
            <Share2 size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className={`rounded-2xl p-6 border ${cardClass}`}>
          <h3 className={`text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2 ${accentText}`}>
            <Info size={14} /> Permitted Builds
          </h3>
          <ul className="grid grid-cols-1 gap-3">
            {analysis.allowableBuilds.map((item, i) => (
              <li key={i} className={`flex items-center gap-3 text-sm ${theme === 'light' ? 'text-zinc-600' : 'text-zinc-300'}`}>
                <div className={`w-1 h-1 rounded-full ${theme === 'light' ? 'bg-purple-500' : 'bg-[#D4AF37]'}`} /> {item}
              </li>
            ))}
          </ul>
        </section>

        <section className={`rounded-2xl p-6 border ${cardClass}`}>
          <h3 className="text-xs font-bold text-red-500 uppercase tracking-widest mb-4 flex items-center gap-2">
            <Shield size={14} /> Regulatory Constraints
          </h3>
          <ul className="grid grid-cols-1 gap-3">
            {analysis.restrictions.map((item, i) => (
              <li key={i} className={`flex items-center gap-3 text-sm ${theme === 'light' ? 'text-zinc-500' : 'text-zinc-400'}`}>
                <div className="w-1 h-1 bg-red-400/50 rounded-full" /> {item}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className={`border rounded-2xl p-6 ${summaryClass}`}>
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4">Executive Summary</h3>
        <p className="text-sm lg:text-base leading-relaxed italic">
          {analysis.summary}
        </p>
      </div>

      <div className="space-y-4">
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Digital Grounding</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {analysis.citations.map((cite, i) => (
            <a key={i} href={cite.url} target="_blank" rel="noopener" className={`p-4 border rounded-xl transition-all block ${cardClass} hover:border-zinc-400`}>
              <p className={`text-xs font-bold truncate mb-2 ${theme === 'light' ? 'text-zinc-800' : 'text-zinc-300'}`}>{cite.title}</p>
              <div className="flex items-center gap-1 text-[10px] text-zinc-500 uppercase font-bold tracking-tighter">
                <ExternalLink size={10} /> View Ordinance
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;
