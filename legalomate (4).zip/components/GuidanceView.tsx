
import React from 'react';
import { CheckCircle, AlertTriangle, Shield, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

const GuidanceView: React.FC = () => {
  const { theme } = useApp();
  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const cardClass = theme === 'light' ? 'bg-white border-zinc-200' : 'bg-zinc-900/40 border-zinc-800';

  const rules = [
    { title: 'High Contrast Uploads', desc: 'Ensure your site plans are clear and scanned at 300DPI for accurate line detection.' },
    { title: 'Address Precision', desc: 'Use full legal addresses including city and pincode to improve jurisdiction detection.' },
    { title: 'Grounding Verification', desc: 'Always cross-reference AI findings with the provided Digital Grounding URLs.' },
    { title: 'Contextual Chat', desc: 'Ask specific questions like "What is the rear setback for a 2-storey house?" for best results.' }
  ];

  return (
    <div className="p-6 lg:p-12 space-y-10 animate-in fade-in duration-500">
      <div>
        <h2 className="text-3xl font-bold">System Guidance</h2>
        <p className="text-zinc-500 mt-1">Protocols for effective bureaucracy breaking</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="space-y-6">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <CheckCircle className={accentText} size={20} /> Operational Rules
          </h3>
          <div className="space-y-4">
            {rules.map((rule, idx) => (
              <div key={idx} className={`p-6 rounded-2xl border ${cardClass}`}>
                <h4 className="font-bold text-sm mb-1">{rule.title}</h4>
                <p className="text-xs text-zinc-500">{rule.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-8">
          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-6">
            <h3 className="text-red-500 font-bold flex items-center gap-2 mb-4">
              <AlertTriangle size={20} /> Legal Disclaimer
            </h3>
            <p className="text-xs text-red-500/80 leading-relaxed italic">
              LegaloMate is an AI assistant designed to facilitate the understanding of complex laws. It is not a licensed legal professional or architect. Always consult local municipal officers before commencing physical construction.
            </p>
          </div>

          <div className={`p-8 rounded-3xl border ${cardClass} space-y-4`}>
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-full ${theme === 'light' ? 'bg-purple-100 text-purple-600' : 'bg-[#D4AF37]/10 text-[#D4AF37]'}`}>
                <Shield size={24} />
              </div>
              <h3 className="text-xl font-bold">Data Privacy</h3>
            </div>
            <p className="text-sm text-zinc-500">
              Analyses are stored locally in your browser cache for privacy. Clear history at any time in the Past Analyses view.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default GuidanceView;
