
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, X, MessageSquareOff } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { gemini } from '../services/geminiService';

const ChatPanel: React.FC = () => {
  const { analysis, chatHistory, addChatMessage, updateLastChatMessage, theme, setChatOpen } = useApp();
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [chatHistory, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || !analysis || isTyping) return;
    
    const userMsg = { role: 'user' as const, content: input };
    addChatMessage(userMsg);
    setInput('');
    setIsTyping(true);

    // Add a placeholder message for streaming
    addChatMessage({ role: 'model', content: '' });

    try {
      await gemini.chatWithContextStream(input, analysis, (fullText) => {
        updateLastChatMessage(fullText);
      });
    } catch (err) {
      updateLastChatMessage("Database access intermittent. Local ordinance cache temporarily unavailable.");
    } finally {
      setIsTyping(false);
    }
  };

  const panelClass = theme === 'light'
    ? 'bg-white lg:border-zinc-200'
    : 'bg-[#121212] lg:bg-black/40 lg:border-zinc-800 lg:backdrop-filter lg:backdrop-blur-xl';

  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const userBubble = theme === 'light' ? 'bg-purple-600 text-white' : 'bg-[#D4AF37] text-black';

  return (
    <div className={`fixed inset-0 lg:relative lg:inset-auto w-full lg:w-[480px] flex flex-col z-[100] lg:z-10 h-full border-t lg:border-t-0 lg:border-l shrink-0 animate-in lg:slide-in-from-right slide-in-from-bottom duration-300 ${panelClass}`}>
      <div className={`p-4 lg:p-6 border-b flex justify-between items-center shrink-0 ${theme === 'light' ? 'border-zinc-100' : 'border-zinc-800 bg-black/20'}`}>
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${theme === 'light' ? 'bg-purple-50 text-purple-600' : 'bg-zinc-900 text-[#D4AF37]'}`}>
            <Bot size={18} />
          </div>
          <div>
            <h3 className={`${accentText} font-bold uppercase text-[10px] tracking-widest`}>
              Legalo Assistant <span className="text-[8px] text-zinc-600 ml-1">FLASH ENABLED</span>
            </h3>
            <p className="text-[10px] text-zinc-500 font-medium italic">Instantaneous municipal retrieval active</p>
          </div>
        </div>
        <button onClick={() => setChatOpen(false)} className="p-2 -mr-2 text-zinc-500 hover:text-red-500 transition-colors active:scale-90">
          <X size={24} />
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6">
        {chatHistory.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center py-12 opacity-30">
            <MessageSquareOff size={64} className="mb-4 text-zinc-600" />
            <p className="text-xs uppercase tracking-[0.2em] font-bold">Encrypted Channel Open</p>
            <p className="text-[10px] mt-2 max-w-[240px]">The Gemini Flash Reasoning Engine is ready for your property inquiries.</p>
          </div>
        )}
        {chatHistory.map((msg, i) => (
          <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm ${
              msg.role === 'user' ? userBubble : (theme === 'light' ? 'bg-zinc-100 text-purple-600' : 'bg-zinc-800 text-[#D4AF37]')
            }`}>
              {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
            </div>
            <div className={`p-4 rounded-2xl text-sm lg:text-base leading-relaxed shadow-sm max-w-[85%] ${
              msg.role === 'user' 
              ? userBubble 
              : (theme === 'light' ? 'bg-zinc-50 text-zinc-700 border border-zinc-100' : 'bg-zinc-900/80 text-zinc-300 border border-zinc-800')
            }`}>
              {msg.content || (msg.role === 'model' && isTyping && i === chatHistory.length - 1 ? <div className="flex gap-1 h-4 items-center"><div className="w-1 h-1 bg-white rounded-full animate-bounce"></div><div className="w-1 h-1 bg-white rounded-full animate-bounce delay-75"></div><div className="w-1 h-1 bg-white rounded-full animate-bounce delay-150"></div></div> : null)}
            </div>
          </div>
        ))}
      </div>

      <div className={`p-4 pb-8 lg:pb-4 border-t ${theme === 'light' ? 'border-zinc-100 bg-zinc-50/50' : 'border-zinc-800 bg-black/40'}`}>
        <div className="relative max-w-4xl mx-auto">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={!analysis || isTyping}
            placeholder={analysis ? "Query property laws..." : "Awaiting analysis..."}
            className={`w-full border rounded-2xl px-6 py-4 text-sm focus:outline-none transition-all pr-14 shadow-inner ${
              theme === 'light' 
                ? 'bg-white border-zinc-200 text-zinc-900 focus:border-purple-600 placeholder:text-zinc-300' 
                : 'bg-zinc-950 border-zinc-800 text-white focus:border-[#D4AF37] placeholder:text-zinc-700'
            }`}
          />
          <button 
            onClick={handleSend}
            disabled={!analysis || isTyping || !input.trim()}
            className={`absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-xl disabled:opacity-20 transition-all ${accentText} hover:scale-110 active:scale-90`}
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;
