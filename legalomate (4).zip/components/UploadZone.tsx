import React, { useState } from 'react';
// Added Loader2 to imports from lucide-react to fix compilation error on line 113
import { Upload, MapPin, Search, FileText, Image as ImageIcon, X, Loader2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { gemini } from '../services/geminiService';
import { AppError } from '../types';

const UploadZone: React.FC = () => {
  const { setAnalysis, uploadedFiles, setUploadedFiles, setIsLoading, isLoading, setError, theme } = useApp();
  const [address, setAddress] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const accentBg = theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]';
  const accentBorder = theme === 'light' ? 'border-purple-600' : 'border-[#D4AF37]';
  const inputBg = theme === 'light' ? 'bg-white' : 'bg-zinc-900/50';

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setUploadedFiles([...uploadedFiles, ...Array.from(e.target.files)]);
    }
  };

  const handleAnalyze = async () => {
    if (!address || uploadedFiles.length === 0) return;
    setIsLoading(true);
    try {
      const result = await gemini.analyzeZoning(address, uploadedFiles);
      const enrichedResult = {
        ...result,
        id: crypto.randomUUID(),
        timestamp: Date.now()
      };
      setAnalysis(enrichedResult);
    } catch (err: any) {
      const errCode = err.message as AppError;
      let msg = "Something went wrong during the legal cross-reference.";
      if (errCode === AppError.VIS_BLUR) msg = "The uploaded images or PDFs are too blurry or unreadable.";
      if (errCode === AppError.NO_DATA) msg = "We could not find relevant zoning data for this location.";
      if (errCode === AppError.AUTH_API) msg = "AI Authentication failed. API key required.";
      setError({ code: errCode || AppError.GENERIC, message: msg });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex items-start lg:items-center justify-center p-6 lg:p-12 overflow-y-auto h-full">
      <div className="w-full max-w-3xl space-y-8 lg:space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-700 py-6 lg:py-0">
        <div className="text-center space-y-4">
          <h2 className="text-3xl lg:text-5xl font-bold tracking-tight px-4 leading-tight">
            Break the <span className={accentText}>Bureaucracy</span>
          </h2>
          <p className="text-zinc-500 text-sm lg:text-lg max-w-xl mx-auto font-light leading-relaxed px-6">
            Audit building codes in seconds. Upload plans or site photos to start the legal audit.
          </p>
        </div>

        <div className="space-y-6">
          <div className="relative group px-1 lg:px-0">
            <div className="absolute inset-y-0 left-5 lg:left-5 flex items-center pointer-events-none">
              <MapPin size={22} className={accentText} />
            </div>
            <input 
              type="text"
              placeholder="Property address..."
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className={`w-full border-2 rounded-2xl py-5 lg:py-6 pl-14 pr-6 text-base lg:text-xl focus:outline-none transition-all placeholder:text-zinc-500 font-medium shadow-2xl ${inputBg} ${theme === 'light' ? 'border-zinc-200 focus:border-purple-600' : 'border-zinc-800 focus:border-[#D4AF37]'}`}
            />
          </div>

          <div 
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => { e.preventDefault(); setIsDragging(false); if(e.dataTransfer.files) setUploadedFiles([...uploadedFiles, ...Array.from(e.dataTransfer.files)]); }}
            className={`relative border-2 border-dashed rounded-3xl p-8 lg:p-12 text-center transition-all cursor-pointer group mx-1 lg:mx-0 ${
              isDragging ? `${accentBorder} bg-opacity-10 ${accentBg}` : `${theme === 'light' ? 'border-zinc-200 bg-zinc-50 hover:border-purple-300' : 'border-zinc-800 bg-black/40 hover:border-zinc-600'}`
            }`}
          >
            <input type="file" multiple accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
            <div className="space-y-4">
              <div className={`w-14 h-14 lg:w-16 lg:h-16 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform shadow-xl ${theme === 'light' ? 'bg-white text-purple-600' : 'bg-zinc-900 text-[#D4AF37]'}`}>
                <Upload size={28} />
              </div>
              <div>
                <p className="font-bold text-base lg:text-lg tracking-tight">Tap to upload site plans</p>
                <p className="text-zinc-500 text-xs mt-1">Images or PDF documents</p>
              </div>
            </div>
          </div>

          {uploadedFiles.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-1 lg:px-0">
              {uploadedFiles.map((file, i) => (
                <div key={i} className={`border rounded-xl p-3 relative group ${theme === 'light' ? 'bg-white border-zinc-200 shadow-sm' : 'bg-zinc-900 border-zinc-800'}`}>
                  <button onClick={() => setUploadedFiles(uploadedFiles.filter((_, idx) => idx !== i))} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1.5 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity z-10 shadow-lg"><X size={10} /></button>
                  <div className="flex flex-col items-center gap-2 overflow-hidden">
                    {file.type.startsWith('image/') ? <ImageIcon size={20} className={accentText} /> : <FileText size={20} className="text-blue-400" />}
                    <span className="text-[9px] text-zinc-400 truncate w-full text-center font-bold uppercase">{file.name}</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="px-1 lg:px-0 pt-4">
            <button 
              onClick={handleAnalyze}
              disabled={!address || uploadedFiles.length === 0 || isLoading}
              className={`w-full py-5 lg:py-6 rounded-2xl font-bold text-lg lg:text-xl transition-all shadow-xl active:scale-[0.95] flex items-center justify-center gap-3 ${accentBg} ${theme === 'light' ? 'text-white' : 'text-black'} disabled:bg-zinc-800 disabled:text-zinc-600`}
            >
              {isLoading ? <><Loader2 size={24} className="animate-spin" /> Analyzing...</> : <><Search size={22} /> Begin Legal Audit</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UploadZone;