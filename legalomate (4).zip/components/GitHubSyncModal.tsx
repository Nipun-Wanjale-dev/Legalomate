
import React, { useState } from 'react';
import { Github, X, Send, CheckCircle, Loader2, ExternalLink, Shield } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { github } from '../services/githubService';

interface Props {
  onClose: () => void;
}

const GitHubSyncModal: React.FC<Props> = ({ onClose }) => {
  const { analysis, theme } = useApp();
  const [repo, setRepo] = useState('legal-audits');
  const [token, setToken] = useState('');
  const [status, setStatus] = useState<'idle' | 'pushing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [url, setUrl] = useState('');

  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const accentBg = theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]';
  const borderClass = theme === 'light' ? 'border-zinc-200' : 'border-[#D4AF37]/30';

  const handlePush = async () => {
    if (!analysis || !token || !repo) return;
    setStatus('pushing');
    try {
      const resultUrl = await github.pushAudit(repo, token, analysis);
      setUrl(resultUrl);
      setStatus('success');
    } catch (err: any) {
      setErrorMsg(err.message);
      setStatus('error');
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className={`w-full max-w-lg bg-[#1a1a1a] border-2 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(212,175,55,0.2)] ${borderClass}`}>
        <div className="p-8 space-y-8">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${theme === 'light' ? 'bg-purple-50 text-purple-600' : 'bg-zinc-900 text-[#D4AF37]'}`}>
                <Github size={24} />
              </div>
              <div>
                <h3 className={`text-xl font-bold ${accentText}`}>Repository Sync</h3>
                <p className="text-zinc-500 text-xs">Push legal audit to GitHub</p>
              </div>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
              <X size={24} />
            </button>
          </div>

          {status === 'success' ? (
            <div className="text-center py-8 space-y-6 animate-in zoom-in duration-300">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center text-green-500">
                  <CheckCircle size={40} />
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="text-lg font-bold text-white">Audit Synced Successfully</h4>
                <p className="text-zinc-500 text-sm px-8">The zoning report has been committed to your repository.</p>
              </div>
              <div className="flex flex-col gap-3">
                <a 
                  href={url} 
                  target="_blank" 
                  rel="noopener"
                  className={`w-full py-4 rounded-xl flex items-center justify-center gap-2 font-bold ${accentBg} ${theme === 'light' ? 'text-white' : 'text-black'}`}
                >
                  View on GitHub <ExternalLink size={18} />
                </a>
                <button onClick={onClose} className="text-zinc-500 text-sm font-bold uppercase tracking-widest hover:text-white py-2">
                  Dismiss
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Repository Name</label>
                  <input 
                    type="text" 
                    placeholder="e.g. legal-audits"
                    value={repo}
                    onChange={(e) => setRepo(e.target.value)}
                    className="w-full bg-black/40 border border-zinc-800 focus:border-[#D4AF37] rounded-xl py-4 px-5 text-white outline-none transition-all placeholder:text-zinc-800"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Personal Access Token</label>
                  <input 
                    type="password" 
                    placeholder="ghp_xxxxxxxxxxxx"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    className="w-full bg-black/40 border border-zinc-800 focus:border-[#D4AF37] rounded-xl py-4 px-5 text-white outline-none transition-all placeholder:text-zinc-800"
                  />
                  <p className="text-[9px] text-zinc-600 flex items-center gap-1 mt-2">
                    <Shield size={10} /> Not stored. Used only for this push.
                  </p>
                </div>
              </div>

              {status === 'error' && (
                <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-medium">
                  {errorMsg}
                </div>
              )}

              <button 
                onClick={handlePush}
                disabled={status === 'pushing' || !token}
                className={`w-full py-5 rounded-xl font-bold transition-all active:scale-[0.98] flex items-center justify-center gap-3 ${
                  token ? accentBg + ' ' + (theme === 'light' ? 'text-white' : 'text-black') : 'bg-zinc-800 text-zinc-600'
                }`}
              >
                {status === 'pushing' ? (
                  <><Loader2 size={20} className="animate-spin" /> Initializing Sync...</>
                ) : (
                  <><Send size={18} /> Push to GitHub</>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GitHubSyncModal;
