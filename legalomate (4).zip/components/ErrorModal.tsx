
import React from 'react';
import { XCircle, RefreshCcw } from 'lucide-react';
import { useApp } from '../context/AppContext';

const ErrorModal: React.FC = () => {
  const { error, setError, resetSession } = useApp();

  if (!error) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-[#1a1a1a] border-2 border-[#D4AF37] rounded-2xl w-full max-w-md overflow-hidden shadow-[0_0_50px_rgba(212,175,55,0.3)] animate-in fade-in zoom-in duration-300">
        <div className="p-8 text-center">
          <div className="flex justify-center mb-6">
            <XCircle size={64} className="text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-[#D4AF37] mb-2 uppercase tracking-widest">Bureaucracy Halted</h2>
          <p className="text-zinc-400 mb-6 font-light leading-relaxed">
            {error.message}
          </p>
          <div className="bg-black/50 border border-zinc-800 rounded-lg p-3 mb-8">
            <span className="text-xs uppercase text-zinc-500 font-bold block mb-1">System Error Code</span>
            <code className="text-[#D4AF37] font-mono text-lg font-bold">{error.code}</code>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => setError(null)}
              className="px-6 py-3 border border-zinc-700 text-zinc-300 rounded-xl hover:bg-zinc-800 transition-all font-semibold"
            >
              Dismiss
            </button>
            <button 
              onClick={() => { resetSession(); setError(null); }}
              className="px-6 py-3 bg-[#D4AF37] text-black rounded-xl hover:bg-[#b8972f] transition-all font-bold flex items-center justify-center gap-2"
            >
              <RefreshCcw size={18} />
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorModal;
