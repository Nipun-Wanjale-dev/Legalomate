
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Book, Info, Search, Loader2, Scale, Building2, Ruler } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { gemini } from '../services/geminiService';

const DetailedLawView: React.FC = () => {
  const { theme, selectedCity, setActiveView } = useApp();
  const [activeCategory, setActiveCategory] = useState('General Zoning');
  const [content, setContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const categories = [
    { name: 'General Zoning', icon: Building2 },
    { name: 'FSI & FAR', icon: Scale },
    { name: 'Setbacks & Open Space', icon: Ruler },
    { name: 'Parking Norms', icon: Info },
    { name: 'Environmental & CRZ', icon: Book },
  ];

  const fetchDetails = async (category: string) => {
    if (!selectedCity) return;
    setIsLoading(true);
    try {
      const explanation = await gemini.getDetailedLegalExplanation(selectedCity, category);
      setContent(explanation);
    } catch (err) {
      setContent("Legal database synchronization failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDetails(activeCategory);
  }, [selectedCity, activeCategory]);

  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const cardClass = theme === 'light' ? 'bg-white border-zinc-200 shadow-lg' : 'bg-zinc-900/60 border-zinc-800';

  return (
    <div className="p-6 lg:p-12 h-full flex flex-col animate-in fade-in duration-500 pb-24">
      <div className="flex items-center gap-4 mb-8">
        <button 
          onClick={() => setActiveView('knowledge')}
          className={`p-3 rounded-full transition-all ${theme === 'light' ? 'hover:bg-purple-100 text-purple-600' : 'hover:bg-zinc-800 text-[#D4AF37]'}`}
        >
          <ArrowLeft size={24} />
        </button>
        <div>
          <h2 className="text-3xl font-bold">{selectedCity} Zonal Laws</h2>
          <p className="text-zinc-500 text-sm">Deep dive into official municipal ordinances</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-8 overflow-hidden">
        {/* Navigation Rail */}
        <div className="w-full lg:w-72 space-y-2 shrink-0">
          {categories.map((cat) => (
            <button
              key={cat.name}
              onClick={() => setActiveCategory(cat.name)}
              className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all text-left group ${
                activeCategory === cat.name 
                ? (theme === 'light' ? 'bg-purple-600 text-white shadow-lg' : 'bg-[#D4AF37] text-black shadow-[0_0_20px_rgba(212,175,55,0.3)]')
                : (theme === 'light' ? 'bg-white border border-zinc-100 hover:bg-purple-50 text-zinc-500' : 'bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-500')
              }`}
            >
              <cat.icon size={20} className={activeCategory === cat.name ? '' : 'group-hover:text-white'} />
              <span className="text-sm font-bold tracking-tight">{cat.name}</span>
            </button>
          ))}
          
          <div className={`mt-10 p-6 rounded-3xl border border-dashed ${theme === 'light' ? 'border-purple-200 bg-purple-50' : 'border-zinc-800 bg-black/20'}`}>
            <h4 className={`text-xs font-bold uppercase tracking-widest mb-2 ${accentText}`}>AI Reasoning</h4>
            <p className="text-[10px] text-zinc-500 leading-relaxed italic">
              Our model decodes UDCPR, RMP, and Master Plan clauses in real-time using search grounding for 100% accuracy.
            </p>
          </div>
        </div>

        {/* Content Area */}
        <div className={`flex-1 rounded-3xl border overflow-y-auto ${cardClass} p-8 lg:p-12 relative min-h-[400px]`}>
          {isLoading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
              <Loader2 size={48} className={`animate-spin ${accentText}`} />
              <p className={`text-xs font-bold uppercase tracking-[0.2em] ${accentText}`}>Retrieving Official Ordinance...</p>
            </div>
          ) : (
            <div className="prose prose-zinc lg:prose-lg max-w-none prose-invert animate-in slide-in-from-bottom-4 duration-500">
              <div className={`inline-block px-4 py-1 rounded-full mb-8 text-[10px] font-bold uppercase tracking-widest ${theme === 'light' ? 'bg-purple-100 text-purple-600' : 'bg-zinc-800 text-[#D4AF37]'}`}>
                {activeCategory} Breakdown
              </div>
              <div className={`whitespace-pre-wrap leading-relaxed ${theme === 'light' ? 'text-zinc-700' : 'text-zinc-300'}`}>
                {content}
              </div>
              
              <div className="mt-12 pt-12 border-t border-zinc-800 flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between opacity-60">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest">
                  <Scale size={16} className={accentText} />
                  Legal Integrity Checked
                </div>
                <div className="text-[10px] font-mono">
                  GROUNDED: GOOGLE SEARCH API | VERSION: GEMINI-3-PRO
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DetailedLawView;
