
import React from 'react';
import { LayoutDashboard, History, FileText, Settings, HelpCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ViewType } from '../types';

const BottomNav: React.FC = () => {
  const { activeView, setActiveView, theme } = useApp();

  const navItems: { icon: any; label: string; view: ViewType }[] = [
    { icon: LayoutDashboard, label: 'Work', view: 'workbench' },
    { icon: History, label: 'Past', view: 'history' },
    { icon: FileText, label: 'Law', view: 'knowledge' },
    { icon: HelpCircle, label: 'Guide', view: 'guidance' },
    { icon: Settings, label: 'Set', view: 'settings' },
  ];

  const containerClass = theme === 'light' 
    ? 'bg-white/90 border-zinc-100 text-zinc-400' 
    : 'bg-[#111111]/90 border-zinc-800 text-zinc-500';

  const activeText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';

  return (
    <nav className={`fixed bottom-0 left-0 right-0 h-20 px-4 flex items-center justify-around z-30 backdrop-blur-2xl border-t pb-safe ${containerClass}`}>
      {navItems.map((item, idx) => (
        <button
          key={idx}
          onClick={() => setActiveView(item.view)}
          className={`flex flex-col items-center gap-1 transition-all active:scale-90 ${
            activeView === item.view ? activeText : ''
          }`}
        >
          <item.icon size={22} className={activeView === item.view ? 'animate-pulse' : ''} />
          <span className="text-[10px] font-bold uppercase tracking-tighter">{item.label}</span>
          {activeView === item.view && (
            <div className={`w-1 h-1 rounded-full mt-1 ${theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]'}`} />
          )}
        </button>
      ))}
    </nav>
  );
};

export default BottomNav;
