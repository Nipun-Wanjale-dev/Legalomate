
import React from 'react';
import { History, MapPin, ChevronRight, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

const HistoryView: React.FC = () => {
  const { history, setAnalysis, clearHistory, theme } = useApp();
  
  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const cardClass = theme === 'light' ? 'bg-white border-zinc-200' : 'bg-zinc-900/40 border-zinc-800';

  return (
    <div className="p-6 lg:p-12 space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Past Analyses</h2>
          <p className="text-zinc-500 mt-1">Review your previously audited properties</p>
        </div>
        {history.length > 0 && (
          <button 
            onClick={clearHistory}
            className="flex items-center gap-2 text-red-500 hover:text-red-400 text-sm font-bold uppercase tracking-widest"
          >
            <Trash2 size={16} /> Clear All
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-32 text-zinc-600 space-y-4">
          <History size={64} className="opacity-20" />
          <p className="text-lg">No records found. Start an analysis on the Workbench.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {history.map((item) => (
            <div 
              key={item.id}
              onClick={() => setAnalysis(item)}
              className={`p-6 rounded-2xl border transition-all hover:scale-[1.02] cursor-pointer group ${cardClass}`}
            >
              <div className="flex justify-between items-start mb-4">
                <div className={`p-2 rounded-lg ${theme === 'light' ? 'bg-purple-100' : 'bg-[#D4AF37]/10'}`}>
                  <MapPin size={20} className={accentText} />
                </div>
                <span className="text-[10px] font-bold text-zinc-500 uppercase">{new Date(item.timestamp).toLocaleDateString()}</span>
              </div>
              <h3 className="text-lg font-bold group-hover:text-[#D4AF37] transition-colors">{item.address}</h3>
              <p className="text-sm text-zinc-500 mt-2 line-clamp-2">{item.summary}</p>
              <div className="mt-6 flex items-center justify-between">
                <span className={`text-xs font-bold uppercase tracking-widest ${accentText}`}>{item.zoningDistrict}</span>
                <ChevronRight size={16} className="text-zinc-700 group-hover:text-white" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryView;
