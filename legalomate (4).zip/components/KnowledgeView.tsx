
import React from 'react';
import { Search, Map, Info, BookOpen, ChevronRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

const KnowledgeView: React.FC = () => {
  const { theme, setSelectedCity, setActiveView } = useApp();
  const accentText = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const cardClass = theme === 'light' ? 'bg-white border-zinc-200 shadow-sm' : 'bg-zinc-900/40 border-zinc-800';

  const cities = [
    { 
      name: 'Mumbai', 
      authority: 'MCGM', 
      rules: 'UDCPR 2020. FSI rules vary by island vs suburbs. CRZ (Coastal Regulation Zone) is critical.',
      tags: ['DCR', 'FSI', 'CRZ']
    },
    { 
      name: 'Pune', 
      authority: 'PMC / PCMC', 
      rules: 'Unified DCPR applies. High-density corridors near Metro lines get bonus FSI.',
      tags: ['PMC', 'Metro Zone']
    },
    { 
      name: 'Bengaluru', 
      authority: 'BBMP', 
      rules: 'Revised Master Plan (RMP) 2031. Setback rules depend on road width and building height.',
      tags: ['Akrama Sakrama', 'RMP']
    },
    { 
      name: 'Delhi', 
      authority: 'DDA', 
      rules: 'Master Plan Delhi (MPD) 2021. Mixed-use residential rules are highly regulated.',
      tags: ['DDA', 'Mixed Use']
    },
    { 
      name: 'Hyderabad', 
      authority: 'GHMC', 
      rules: 'GO MS No. 168. No FSI limit for residential; height depends on the road width.',
      tags: ['GHMC', 'Unlimited FSI']
    },
    { 
      name: 'Noida', 
      authority: 'Noida Auth', 
      rules: 'Industrial vs Residential sectors. FAR calculation includes green area deductions.',
      tags: ['FAR', 'Leasehold']
    }
  ];

  const handleExplore = (cityName: string) => {
    setSelectedCity(cityName);
    setActiveView('detailed_law');
  };

  return (
    <div className="p-6 lg:p-12 space-y-10 animate-in fade-in duration-500 pb-24">
      <div>
        <h2 className="text-3xl font-bold">Zoning Knowledge Base</h2>
        <p className="text-zinc-500 mt-1">Core regulations for India's major metropolitan hubs</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {cities.map((city, idx) => (
          <div key={idx} className={`p-8 rounded-3xl border ${cardClass} space-y-4 group transition-all hover:scale-[1.02]`}>
            <div className="flex justify-between items-start">
              <h3 className="text-xl font-bold">{city.name}</h3>
              <span className={`text-[10px] font-bold px-2 py-1 rounded border ${theme === 'light' ? 'border-purple-200 bg-purple-50 text-purple-600' : 'border-[#D4AF37]/20 bg-[#D4AF37]/5 text-[#D4AF37]'}`}>
                {city.authority}
              </span>
            </div>
            <p className="text-sm text-zinc-500 leading-relaxed h-12 line-clamp-2">{city.rules}</p>
            <div className="flex flex-wrap gap-2 pt-2">
              {city.tags.map(tag => (
                <span key={tag} className="text-[9px] uppercase font-bold text-zinc-600 bg-zinc-800/10 px-2 py-1 rounded">
                  {tag}
                </span>
              ))}
            </div>
            <button 
              onClick={() => handleExplore(city.name)}
              className={`w-full py-3 rounded-xl mt-4 border flex items-center justify-center gap-2 font-bold text-xs uppercase tracking-widest transition-all ${
                theme === 'light' ? 'border-purple-200 text-purple-600 hover:bg-purple-600 hover:text-white' : 'border-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black'
              }`}
            >
              Explore Detailed Law <ChevronRight size={14} />
            </button>
          </div>
        ))}
      </div>

      <div className={`p-8 rounded-3xl border shadow-xl ${theme === 'light' ? 'bg-purple-600 text-white' : 'bg-[#D4AF37] text-black'}`}>
        <div className="flex gap-4 items-start">
          <BookOpen size={32} />
          <div>
            <h4 className="text-xl font-bold">Understanding NBC 2016</h4>
            <p className="opacity-80 mt-1 text-sm leading-relaxed">The National Building Code (NBC) provides the technical framework for safety, stability, and aesthetics across all Indian cities. Every zonal plan must align with NBC guidelines.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeView;
