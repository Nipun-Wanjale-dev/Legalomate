
import React from 'react';
import { FileDown, Printer } from 'lucide-react';
import { useApp } from '../context/AppContext';

const PermitPreview: React.FC = () => {
  /**
   * These properties now exist on AppContextType.
   */
  const { permitData, setPermitData } = useApp();

  if (!permitData) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 lg:p-12 overflow-y-auto">
      <div className="bg-white text-black w-full max-w-4xl min-h-[11in] rounded-sm shadow-2xl p-12 relative flex flex-col font-serif border-[12px] border-zinc-100">
        <button 
          onClick={() => setPermitData(null)}
          className="absolute top-6 right-6 text-zinc-400 hover:text-black transition-colors no-print"
        >
          Close Preview
        </button>

        <div className="border-b-4 border-black pb-8 mb-8 flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-bold uppercase tracking-tight">{permitData.templateName}</h1>
            <p className="text-zinc-600 mt-2 italic">Jurisdiction: {permitData.jurisdiction} | AI-Pre-filled</p>
          </div>
          <div className="text-right">
            <div className="text-xs font-bold text-zinc-400 mb-1">SYSTEM TIMESTAMP</div>
            <p className="text-xs font-mono">{new Date().toLocaleDateString()}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-12 mb-12">
          <div className="space-y-8">
            <h3 className="text-xs font-bold border-b border-black pb-1 uppercase tracking-widest">Section I: Administrative</h3>
            {Object.entries(permitData.mainFields).map(([key, val]) => (
              <div key={key}>
                <label className="text-[9px] uppercase font-bold text-zinc-500 block mb-1">{key.replace(/([A-Z])/g, ' $1')}</label>
                {/* Fixed: TypeScript cast to ReactNode to satisfy rendering requirements */}
                <div className="border-b border-zinc-200 pb-1 text-sm font-medium">{val as React.ReactNode}</div>
              </div>
            ))}
          </div>

          <div className="space-y-8">
            <h3 className="text-xs font-bold border-b border-black pb-1 uppercase tracking-widest">Section II: Technical</h3>
            <div className="bg-zinc-50 p-6 border border-zinc-200 rounded-lg space-y-4">
              {Object.entries(permitData.technicalDetails).map(([key, val]) => (
                <div key={key}>
                  <label className="text-[9px] uppercase font-bold text-zinc-400 block mb-1">{key.replace(/([A-Z])/g, ' $1')}</label>
                  {/* Fixed: TypeScript cast to ReactNode */}
                  <div className="text-sm font-bold">{val as React.ReactNode}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mb-12">
          <h3 className="text-xs font-bold border-b border-black pb-2 uppercase tracking-widest mb-4">Required Attachments (Checklist)</h3>
          <div className="grid grid-cols-2 gap-4">
            {permitData.requiredAttachments.map((item, idx) => (
              <div key={idx} className="flex items-center gap-3 p-3 bg-zinc-50 rounded-lg border border-zinc-100">
                <div className="w-4 h-4 border border-zinc-400 rounded-sm shrink-0"></div>
                <span className="text-xs text-zinc-600">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-auto border-t-2 border-zinc-100 pt-8 flex justify-between items-center no-print">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-[#D4AF37] rounded-full flex items-center justify-center text-black font-bold text-xs">LM</div>
             <p className="text-[10px] text-zinc-400 max-w-xs leading-tight">
               LegaloMate Verification: Analyzed against {permitData.jurisdiction} building codes.
             </p>
          </div>
          <div className="flex gap-4">
            <button onClick={() => window.print()} className="flex items-center gap-2 px-6 py-3 border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-all font-bold text-sm">
              <Printer size={16} /> Print
            </button>
            <button className="flex items-center gap-2 px-6 py-3 bg-[#D4AF37] text-black rounded-lg hover:bg-[#b8972f] transition-all font-bold shadow-lg text-sm">
              <FileDown size={16} /> Export Document
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PermitPreview;
