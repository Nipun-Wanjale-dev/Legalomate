
import React from 'react';
import { Home } from 'lucide-react';
import { useApp } from '../context/AppContext';

const MobileHeader: React.FC = () => {
  const { theme, activeView } = useApp();

  const accentColor = theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]';
  const logoText = theme === 'light' ? 'text-zinc-900' : 'text-white';
  const logoAccent = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';
  const headerBg = theme === 'light' ? 'bg-white/80' : 'bg-[#111111]/80';

  const getTitle = () => {
    switch (activeView) {
      case 'history': return 'Recent Audits';
      case 'knowledge': return 'Ordinance Library';
      case 'settings': return 'System Settings';
      case 'guidance': return 'Usage Rules';
      default: return 'Workbench';
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-30 h-16 flex items-center justify-between px-6 backdrop-blur-xl border-b ${theme === 'light' ? 'border-zinc-100' : 'border-zinc-800'} ${headerBg}`}>
      <div className="flex items-center gap-2">
        <div className={`w-7 h-7 ${accentColor} rounded flex items-center justify-center`}>
          <Home className={theme === 'light' ? 'text-white' : 'text-black'} size={14} />
        </div>
        <span className={`text-sm font-bold tracking-tighter ${logoText}`}>
          Legalo<span className={logoAccent}>Mate</span>
        </span>
      </div>
      <div className={`text-[10px] font-bold uppercase tracking-widest ${logoAccent}`}>
        {getTitle()}
      </div>
    </header>
  );
};

export default MobileHeader;
