
import React from 'react';
import { Home, FileText, Settings, HelpCircle, History, LayoutDashboard } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ViewType } from '../types';

const Sidebar: React.FC = () => {
  const { activeView, setActiveView, theme } = useApp();

  const menuItems: { icon: any; label: string; view: ViewType }[] = [
    { icon: LayoutDashboard, label: 'Workbench', view: 'workbench' },
    { icon: History, label: 'Past Analyses', view: 'history' },
    { icon: FileText, label: 'Knowledge Base', view: 'knowledge' },
    { icon: Settings, label: 'Preferences', view: 'settings' },
    { icon: HelpCircle, label: 'Guidance', view: 'guidance' },
  ];

  const sidebarClass = theme === 'light' 
    ? 'bg-white border-zinc-200 shadow-xl' 
    : 'glass-sidebar';

  const activeClass = theme === 'light'
    ? 'bg-purple-600 text-white shadow-[0_0_20px_rgba(147,51,234,0.3)]'
    : 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/20 shadow-[0_0_15px_rgba(212,175,55,0.1)]';

  const accentColor = theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]';
  const logoText = theme === 'light' ? 'text-zinc-900' : 'text-white';
  const logoAccent = theme === 'light' ? 'text-purple-600' : 'text-[#D4AF37]';

  return (
    <aside className={`w-full lg:w-64 ${sidebarClass} lg:h-screen flex flex-row lg:flex-col p-4 lg:p-6 transition-all z-20 overflow-hidden`}>
      <div className="mb-0 lg:mb-12 flex items-center gap-3 mr-4 lg:mr-0 shrink-0">
        <div className={`w-8 h-8 lg:w-10 lg:h-10 ${accentColor} rounded-lg flex items-center justify-center shrink-0`}>
          <Home className={theme === 'light' ? 'text-white' : 'text-black'} size={18} />
        </div>
        <h1 className={`hidden lg:block text-xl font-bold tracking-tighter ${logoText}`}>
          Legalo<span className={logoAccent}>Mate</span>
        </h1>
      </div>

      <nav className="flex-1 flex flex-row lg:flex-col gap-2 lg:gap-4 overflow-x-auto lg:overflow-x-visible no-scrollbar px-2 lg:px-0">
        {menuItems.map((item, idx) => (
          <button 
            key={idx}
            onClick={() => setActiveView(item.view)}
            className={`flex items-center gap-4 p-3 lg:p-4 rounded-xl transition-all group shrink-0 ${
              activeView === item.view
              ? activeClass
              : theme === 'light' ? 'text-zinc-400 hover:text-purple-600 hover:bg-purple-50' : 'text-zinc-500 hover:text-white hover:bg-white/5'
            }`}
          >
            <item.icon className="shrink-0" size={20} />
            <span className="hidden lg:block font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
