
import React, { useState } from 'react';
import { Home, ShieldCheck, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Login: React.FC = () => {
  const { login } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email || 'elite.user@legalomate.com');
  };

  return (
    <div className="fixed inset-0 bg-[#121212] flex items-center justify-center p-6 overflow-hidden">
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#D4AF37] blur-[150px] rounded-full" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#D4AF37] blur-[150px] rounded-full" />
      </div>

      <div className="w-full max-w-md space-y-12 relative z-10">
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <div className="w-20 h-20 bg-[#D4AF37] rounded-[2rem] flex items-center justify-center shadow-[0_0_30px_rgba(212,175,55,0.3)] animate-pulse">
              <Home className="text-black" size={40} />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tighter text-white">
              Legalo<span className="text-[#D4AF37]">Mate</span>
            </h1>
            <p className="text-zinc-500 uppercase tracking-[0.4em] text-[10px] font-bold">
              Elite Legal Clarity
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="relative group">
              <input 
                type="email" 
                placeholder="Secure Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-black/40 border border-zinc-800 focus:border-[#D4AF37] rounded-2xl py-5 px-6 text-white transition-all outline-none placeholder:text-zinc-700"
              />
            </div>
            <div className="relative group">
              <input 
                type="password" 
                placeholder="Access Key"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black/40 border border-zinc-800 focus:border-[#D4AF37] rounded-2xl py-5 px-6 text-white transition-all outline-none placeholder:text-zinc-700"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-5 bg-[#D4AF37] text-black font-bold rounded-2xl flex items-center justify-center gap-3 transition-all hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(212,175,55,0.4)] group active:scale-95"
          >
            Sign In to Dashboard <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        <div className="flex items-center justify-center gap-2 text-zinc-600 text-[10px] font-bold uppercase tracking-widest">
          <ShieldCheck size={14} className="text-[#D4AF37]" />
          End-to-End Encrypted Node
        </div>
      </div>
    </div>
  );
};

export default Login;
