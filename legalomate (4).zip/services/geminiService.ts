
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { AppError, AnalysisResult } from "../types";

export class GeminiService {
  private getAI() {
    const apiKey = process.env.API_KEY;
    if (!apiKey) throw new Error(AppError.AUTH_API);
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  private async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async analyzeZoning(address: string, files: File[]): Promise<any> {
    const ai = this.getAI();
    const multimodalParts = await Promise.all(
      files.map(async (f) => ({
        inlineData: { data: await this.fileToBase64(f), mimeType: f.type }
      }))
    );

    // Reserve Gemini 3 Pro for complex vision tasks
    const prompt = `Analyze property at ${address}. 
    Detect Jurisdiction. Analyze zoning laws with Google Search. 
    Act as if you have scanned the latest municipal PDFs for this specific city.
    Return JSON: detectedJurisdiction, zoningDistrict, allowableBuilds, restrictions, citations, summary.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: { parts: [...multimodalParts, { text: prompt }] },
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            error: { type: Type.STRING },
            address: { type: Type.STRING },
            detectedJurisdiction: { type: Type.STRING },
            zoningDistrict: { type: Type.STRING },
            allowableBuilds: { type: Type.ARRAY, items: { type: Type.STRING } },
            restrictions: { type: Type.ARRAY, items: { type: Type.STRING } },
            citations: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT, 
                properties: { 
                  title: { type: Type.STRING }, 
                  url: { type: Type.STRING } 
                } 
              } 
            },
            summary: { type: Type.STRING }
          },
          required: ["detectedJurisdiction", "zoningDistrict", "allowableBuilds", "restrictions", "citations", "summary"]
        }
      }
    });

    const rawText = response.text || '{}';
    let data;
    try {
      data = JSON.parse(rawText);
    } catch (e) {
      const match = rawText.match(/```json\s*([\s\S]*?)\s*```/) || rawText.match(/{[\s\S]*}/);
      const jsonStr = match ? match[1] || match[0] : rawText;
      data = JSON.parse(jsonStr);
    }

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (groundingChunks) {
      groundingChunks.forEach((chunk: any) => {
        if (chunk.web) {
          data.citations.push({
            title: chunk.web.title || 'Official Document',
            url: chunk.web.uri
          });
        }
      });
    }

    if (data.error === 'BLURRY_IMAGE') throw new Error(AppError.VIS_BLUR);
    if (data.error === 'NO_DATA_FOUND') throw new Error(AppError.NO_DATA);
    if (!data.address) data.address = address;

    return data;
  }

  async chatWithContextStream(query: string, analysis: AnalysisResult, onChunk: (text: string) => void): Promise<void> {
    const ai = this.getAI();
    
    // Using Gemini 3 Flash for maximum performance and minimum latency
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: `You are LegaloMate Elite Legal Assistant.
        - USE Google Search to grounded answers in specific municipal building codes for ${analysis.address}.
        - Act as if you have immediate access to all city zoning PDFs.
        - NO symbols like #, *, or bolding.
        - Snap-of-the-finger responses.
        - Context: ${analysis.detectedJurisdiction} zoning for ${analysis.address}.`,
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 0 } // Disable thinking for maximum speed
      }
    });

    const responseStream = await chat.sendMessageStream({ message: query });
    let fullText = "";
    for await (const chunk of responseStream) {
      const text = (chunk as GenerateContentResponse).text;
      if (text) {
        fullText += text;
        onChunk(fullText);
      }
    }
  }

  async getDetailedLegalExplanation(city: string, category: string): Promise<string> {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Detailed legal breakdown of ${category} regulations in ${city}, India. Cite acts/plans. Structure with CAPS headers. No symbols.`,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "Could not retrieve details.";
  }
}

export const gemini = new GeminiService();
