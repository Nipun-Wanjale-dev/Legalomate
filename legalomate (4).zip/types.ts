
export enum AppError {
  NO_DATA = 'ERR_NO_DATA_L4',
  VIS_BLUR = 'ERR_VIS_BLUR_92',
  AUTH_API = 'ERR_AUTH_API_00',
  GENERIC = 'ERR_GENERIC_X1'
}

export type Jurisdiction = 'Maharashtra' | 'India-National' | 'USA' | 'Other';
export type ViewType = 'workbench' | 'history' | 'knowledge' | 'settings' | 'guidance' | 'detailed_law';
export type ThemeType = 'elite' | 'light';

export interface AnalysisResult {
  id: string;
  timestamp: number;
  address: string;
  detectedJurisdiction: Jurisdiction;
  zoningDistrict: string;
  allowableBuilds: string[];
  restrictions: string[];
  citations: { title: string; url: string }[];
  summary: string;
}

export interface PermitData {
  templateName: string;
  jurisdiction: string;
  mainFields: Record<string, any>;
  technicalDetails: Record<string, any>;
  requiredAttachments: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface AppState {
  isAuthenticated: boolean;
  user: { email: string } | null;
  activeView: ViewType;
  theme: ThemeType;
  isChatOpen: boolean;
  analysis: AnalysisResult | null;
  permitData: PermitData | null;
  history: AnalysisResult[];
  uploadedFiles: File[];
  chatHistory: ChatMessage[];
  isLoading: boolean;
  error: { code: AppError; message: string } | null;
  selectedCity: string | null;
}
