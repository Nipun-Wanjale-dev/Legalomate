
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppState, AppError, AnalysisResult, ChatMessage, ViewType, ThemeType, PermitData } from '../types';

interface AppContextType extends AppState {
  login: (email: string) => void;
  logout: () => void;
  setActiveView: (view: ViewType) => void;
  setTheme: (theme: ThemeType) => void;
  setChatOpen: (open: boolean) => void;
  setAnalysis: (analysis: AnalysisResult | null) => void;
  setPermitData: (data: PermitData | null) => void;
  setUploadedFiles: (files: File[]) => void;
  addChatMessage: (msg: ChatMessage) => void;
  updateLastChatMessage: (content: string) => void;
  setIsLoading: (loading: boolean) => void;
  setError: (error: { code: AppError; message: string } | null) => void;
  resetSession: () => void;
  clearHistory: () => void;
  setSelectedCity: (city: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'legalomate_history';
const AUTH_KEY = 'legalomate_auth';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(() => {
    const savedHistory = localStorage.getItem(STORAGE_KEY);
    const savedAuth = localStorage.getItem(AUTH_KEY);
    return {
      isAuthenticated: !!savedAuth,
      user: savedAuth ? JSON.parse(savedAuth) : null,
      activeView: 'workbench',
      theme: 'elite',
      isChatOpen: true,
      analysis: null,
      permitData: null,
      history: savedHistory ? JSON.parse(savedHistory) : [],
      uploadedFiles: [],
      chatHistory: [],
      isLoading: false,
      error: null,
      selectedCity: null,
    };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.history));
  }, [state.history]);

  const login = (email: string) => {
    const user = { email };
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    setState(prev => ({ ...prev, isAuthenticated: true, user }));
  };

  const logout = () => {
    localStorage.removeItem(AUTH_KEY);
    setState(prev => ({ ...prev, isAuthenticated: false, user: null }));
  };

  const setActiveView = (activeView: ViewType) => setState(prev => ({ ...prev, activeView }));
  const setTheme = (theme: ThemeType) => setState(prev => ({ ...prev, theme }));
  const setChatOpen = (isChatOpen: boolean) => setState(prev => ({ ...prev, isChatOpen }));
  
  const setAnalysis = (analysis: AnalysisResult | null) => {
    setState(prev => {
      const newHistory = analysis ? [analysis, ...prev.history].slice(0, 50) : prev.history;
      return { 
        ...prev, 
        analysis, 
        history: newHistory,
        activeView: 'workbench' 
      };
    });
  };

  const setPermitData = (permitData: PermitData | null) => setState(prev => ({ ...prev, permitData }));
  const setUploadedFiles = (uploadedFiles: File[]) => setState(prev => ({ ...prev, uploadedFiles }));
  
  const addChatMessage = (msg: ChatMessage) => 
    setState(prev => ({ ...prev, chatHistory: [...prev.chatHistory, msg] }));

  const updateLastChatMessage = (content: string) => {
    setState(prev => {
      const newHistory = [...prev.chatHistory];
      if (newHistory.length > 0) {
        newHistory[newHistory.length - 1].content = content;
      }
      return { ...prev, chatHistory: newHistory };
    });
  };

  const setIsLoading = (isLoading: boolean) => setState(prev => ({ ...prev, isLoading }));
  const setError = (error: { code: AppError; message: string } | null) => setState(prev => ({ ...prev, error }));
  const setSelectedCity = (selectedCity: string | null) => setState(prev => ({ ...prev, selectedCity }));
  
  const resetSession = () => setState(prev => ({
    ...prev,
    activeView: 'workbench',
    analysis: null,
    permitData: null,
    uploadedFiles: [],
    chatHistory: [],
    isLoading: false,
    error: null,
  }));

  const clearHistory = () => setState(prev => ({ ...prev, history: [] }));

  return (
    <AppContext.Provider value={{ 
      ...state, 
      login,
      logout,
      setActiveView,
      setTheme,
      setChatOpen,
      setAnalysis, 
      setPermitData,
      setUploadedFiles, 
      addChatMessage, 
      updateLastChatMessage,
      setIsLoading, 
      setError,
      resetSession,
      clearHistory,
      setSelectedCity,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
