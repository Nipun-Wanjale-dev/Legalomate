
import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Sidebar from './components/Sidebar';
import BottomNav from './components/BottomNav';
import MobileHeader from './components/MobileHeader';
import UploadZone from './components/UploadZone';
import AnalysisView from './components/AnalysisView';
import ChatPanel from './components/ChatPanel';
import ErrorModal from './components/ErrorModal';
import HistoryView from './components/HistoryView';
import KnowledgeView from './components/KnowledgeView';
import SettingsView from './components/SettingsView';
import GuidanceView from './components/GuidanceView';
import DetailedLawView from './components/DetailedLawView';
import Login from './components/Login';
import { MessageSquare, X } from 'lucide-react';

const ViewRenderer: React.FC = () => {
  const { activeView, analysis } = useApp();

  switch (activeView) {
    case 'history': return <HistoryView />;
    case 'knowledge': return <KnowledgeView />;
    case 'settings': return <SettingsView />;
    case 'guidance': return <GuidanceView />;
    case 'detailed_law': return <DetailedLawView />;
    default: return analysis ? <AnalysisView /> : <UploadZone />;
  }
};

const AppContent: React.FC = () => {
  const { theme, isChatOpen, setChatOpen, analysis, isAuthenticated } = useApp();
  
  if (!isAuthenticated) {
    return <Login />;
  }

  const themeClass = theme === 'light' 
    ? 'bg-zinc-50 text-zinc-900' 
    : 'bg-[#121212] text-white';

  const accentBg = theme === 'light' ? 'bg-purple-600' : 'bg-[#D4AF37]';

  return (
    <div className={`flex flex-col lg:flex-row h-screen overflow-hidden font-montserrat transition-colors duration-500 ${themeClass} select-none`}>
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>

      {/* Mobile Header */}
      <div className="lg:hidden">
        <MobileHeader />
      </div>
      
      <main className="flex-1 flex flex-col lg:flex-row relative overflow-hidden h-full">
        <div className="flex-1 overflow-y-auto main-content h-full">
          <ViewRenderer />
        </div>
        
        {/* Chat Panel - Overlay on Mobile, Side Panel on Desktop */}
        {isChatOpen && <ChatPanel />}
      </main>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden">
        <BottomNav />
      </div>

      {/* Desktop Chat Toggle Switch */}
      {analysis && (
        <button 
          onClick={() => setChatOpen(!isChatOpen)}
          className={`hidden lg:flex fixed bottom-8 right-8 w-12 h-12 rounded-full items-center justify-center shadow-lg transition-all z-50 border ${
            theme === 'light' 
              ? 'bg-white border-purple-200 text-purple-600 hover:bg-purple-50' 
              : 'bg-zinc-900 border-zinc-800 text-[#D4AF37] hover:bg-zinc-800'
          }`}
          title={isChatOpen ? "Close Assistant" : "Open Assistant"}
        >
          {isChatOpen ? <X size={20} /> : <MessageSquare size={20} />}
        </button>
      )}

      {/* Mobile Chat FAB - Only show when analysis is active and chat is closed */}
      {analysis && !isChatOpen && (
        <button 
          onClick={() => setChatOpen(true)}
          className={`lg:hidden fixed bottom-24 right-6 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-90 z-40 ${accentBg} text-white`}
        >
          <MessageSquare size={24} />
        </button>
      )}

      <ErrorModal />
    </div>
  );
};

const App: React.FC = () => (
  <AppProvider>
    <AppContent />
  </AppProvider>
);

export default App;
